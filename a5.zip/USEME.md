### File:
    - New project
    - Load
    - Save Image
    - Save Project
Modifies the project, either allowing to make a new project, load a project, save the image, or
save the project.

### Edit
    - Add image
    - Add layer
    - Color components
    - Brighten
    - Darken
Allows the user to edit the project, either by adding an image, adding a new layer, or by
filtering by color components, brightening, or darkening the layer.